from flask import Flask, render_template, request, redirect, url_for, jsonify
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.orm import sessionmaker, relationship, declarative_base
from datetime import datetime

app = Flask(__name__)

# Database setup
engine = create_engine('sqlite:///general_ledger.db')
Base = declarative_base()

class Account(Base):
    __tablename__ = 'accounts'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    type = Column(String, nullable=False)
    balance = Column(Float, default=0.0)
    transactions = relationship('Transaction', back_populates='account')

class Transaction(Base):
    __tablename__ = 'transactions'
    id = Column(Integer, primary_key=True)
    account_id = Column(Integer, ForeignKey('accounts.id'), nullable=False)
    amount = Column(Float, nullable=False)
    type = Column(String, nullable=False)  # 'debit' or 'credit'
    description = Column(String)
    date = Column(DateTime, default=datetime.utcnow)
    account = relationship('Account', back_populates='transactions')

Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

# Routes

@app.route('/')
def index():
    session = Session()
    accounts = session.query(Account).all()
    return render_template('index.html', accounts=accounts)

@app.route('/add_account', methods=['POST'])
def add_account():
    name = request.form['name']
    type = request.form['type']
    session = Session()
    account = Account(name=name, type=type)
    session.add(account)
    session.commit()
    return redirect(url_for('index'))

@app.route('/add_transaction', methods=['POST'])
def add_transaction():
    account_name = request.form['account_name']
    amount = float(request.form['amount'])
    type = request.form['type']
    description = request.form['description']
    session = Session()

    account = session.query(Account).filter_by(name=account_name).first()
    if not account:
        return "Account not found. Please make sure the account name is correct."

    if type == 'debit':
        account.balance -= amount
    elif type == 'credit':
        account.balance += amount
    else:
        return "Invalid transaction type."

    transaction = Transaction(account_id=account.id, amount=amount, type=type, description=description)
    session.add(transaction)
    session.commit()

    return redirect(url_for('index'))

@app.route('/clear_database', methods=['GET'])
def clear_database():
    session = Session()
    session.query(Account).delete()
    session.query(Transaction).delete()
    session.commit()
    return redirect(url_for('index'))

# Additional Routes for Key Features

@app.route('/get_ledger/<int:account_id>', methods=['GET'])
def get_ledger(account_id):
    session = Session()
    account = session.query(Account).get(account_id)
    if not account:
        return jsonify({"error": "Account not found"})
    ledger = [{
        "date": transaction.date.strftime('%Y-%m-%d'),
        "description": transaction.description,
        "amount": transaction.amount,
        "type": transaction.type
    } for transaction in account.transactions]
    return jsonify({"account_name": account.name, "ledger": ledger})

@app.route('/get_account_balance/<int:account_id>', methods=['GET'])
def get_account_balance(account_id):
    session = Session()
    account = session.query(Account).get(account_id)
    if not account:
        return jsonify({"error": "Account not found"})
    return jsonify({"account_name": account.name, "balance": account.balance})

# Add routes and functionalities for budgeting, expense tracking, income management, and financial reporting as needed

if __name__ == '__main__':
    app.run(debug=True)
