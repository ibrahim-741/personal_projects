// Function to handle product lookup form submission
document.addEventListener('DOMContentLoaded', () => {
    const productForm = document.querySelector('#product-form');
    const resultDiv = document.querySelector('#result');

    productForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const code = document.querySelector('#code').value;
        const response = await fetch('/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `code=${code}`
        });
        const data = await response.text();
        resultDiv.innerHTML = data;
    });
});

// Function to handle transaction analysis form submission
document.addEventListener('DOMContentLoaded', () => {
    const analysisForm = document.querySelector('#analysis-form');
    const analysisDiv = document.querySelector('#analysis');

    analysisForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const deviceCode = document.querySelector('#device_code').value;
        const timePeriod = document.querySelector('#time_period').value;
        const response = await fetch('/analyze', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `device_code=${deviceCode}&time_period=${timePeriod}`
        });
        const data = await response.text();
        analysisDiv.innerHTML = data;
    });
});

// Function to handle URL check form submission
document.addEventListener('DOMContentLoaded', () => {
    const urlCheckForm = document.querySelector('#url-check-form');
    const urlCheckResultDiv = document.querySelector('#url-check-result');

    urlCheckForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const url = document.querySelector('#url').value;
        const response = await fetch('/check_url', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `url=${url}`
        });
        const data = await response.json();
        const result = data.positives > 0 ? 'Malicious' : 'Safe';
        urlCheckResultDiv.innerHTML = `URL is ${result}. Detected ${data.positives} positives out of ${data.total}`;
    });
});

// Function to handle review classification form submission
document.addEventListener('DOMContentLoaded', () => {
    const reviewForm = document.querySelector('#review-form');
    const reviewClassificationDiv = document.querySelector('#review-classification');

    reviewForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const review = document.querySelector('#review').value;
        const response = await fetch('/classify', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ review: review })
        });
        const data = await response.json();
        reviewClassificationDiv.innerHTML = `Review classification: ${data.result}`;
    });
});
