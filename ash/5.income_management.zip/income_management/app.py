from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime
import sqlite3

app = Flask(__name__)

class IncomeDB:
    def __init__(self):
        self.conn = sqlite3.connect('income_management.db')
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS incomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount REAL,
                date TEXT,
                category TEXT,
                description TEXT
            )
        ''')
        self.conn.commit()

    def add_income(self, income):
        self.cursor.execute('''
            INSERT INTO incomes (amount, date, category, description)
            VALUES (?, ?, ?, ?)
        ''', (income.amount, income.date, income.category.name, income.description))
        self.conn.commit()

    def get_all_income_records(self):
        self.cursor.execute('SELECT * FROM incomes')
        return self.cursor.fetchall()

    def clear_data(self):
        self.cursor.execute('DELETE FROM incomes')
        self.conn.commit()

    def close(self):
        self.conn.close()

class Income:
    def __init__(self, amount, date, category, description=None):
        self.amount = amount
        self.date = date
        self.category = category
        self.description = description

class Category:
    def __init__(self, name):
        self.name = name

@app.route('/')
def index():
    db = IncomeDB()
    income_records = db.get_all_income_records()
    db.close()
    return render_template('index.html', income_records=income_records)

@app.route('/add_income', methods=['POST'])
def add_income():
    amount = request.form['amount']
    date = request.form['date']
    category = request.form['category']
    description = request.form.get('description')

    db = IncomeDB()
    income = Income(amount, date, Category(category), description)
    db.add_income(income)
    db.close()

    return redirect(url_for('index'))

@app.route('/clear_data', methods=['POST'])
def clear_data():
    db = IncomeDB()
    db.clear_data()
    db.close()

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
